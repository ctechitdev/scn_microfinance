

const update_user = "update tbl_user set full_name =?,role_id = ?,depart_id =?,user_status = ? where user_id = ?";

module.exports = {
    update_user,
};