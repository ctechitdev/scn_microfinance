
const login_user = "select * from tbl_user where user_name = ? and user_password = ? ";


module.exports = {
    login_user,
};